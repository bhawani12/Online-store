

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dbsaved.citymannager;
import dbsaved.salesmannager;

/**
 * Servlet implementation class salesAction
 */
@WebServlet("/salesAction")
public class salesAction extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public salesAction() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		
		String flag;
		flag=request.getParameter("flag");
		
		String msg;
		
		
		if(flag.equals("save"))
		{

		
		int oid,cusid,pid,quantity,price;
		String pname,orderdate;
		
		oid=Integer.parseInt(request.getParameter("oid"));
		cusid=Integer.parseInt(request.getParameter("cusid"));
		pid=Integer.parseInt(request.getParameter("pid"));
		quantity=Integer.parseInt(request.getParameter("quantity"));
		price=Integer.parseInt(request.getParameter("price"));
		pname=request.getParameter("pname");
		orderdate=request.getParameter("orderdate");
		
		salesmannager obj = new salesmannager();
		try {
			obj.getdata(oid, cusid, pid, quantity, price, pname, orderdate);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
		else if(flag.equals("delete"))
		{
		
			int oid;
			
			oid=Integer.parseInt(  request.getParameter("oid"));
			
			
			
			salesmannager obj = new salesmannager();
			obj.deletedata(oid);
			
			
		}
		
		else if(flag.equals("update"))
		{
			
			int oids,cusids,pids,quantitys,prices;
			String pnames,orderdates;
			
			oids=Integer.parseInt(request.getParameter("oids"));
			cusids=Integer.parseInt(request.getParameter("cusids"));
			pids=Integer.parseInt(request.getParameter("pids"));
			quantitys=Integer.parseInt(request.getParameter("quantitys"));
			prices=Integer.parseInt(request.getParameter("prices"));
			pnames=request.getParameter("pnames");
			orderdates=request.getParameter("orderdates");
			
			salesmannager obj = new salesmannager();
			
			obj.updatedata(oids, cusids, pids, quantitys, prices, pnames, orderdates);
			

			
		}
		
		
		
		
		
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
