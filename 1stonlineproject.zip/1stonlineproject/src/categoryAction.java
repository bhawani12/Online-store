

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dbsaved.categorymannager;
import dbsaved.countrrymannager;
import dbsaved.productmanager;

/**
 * Servlet implementation class categoryAction
 */
@WebServlet("/categoryAction")
public class categoryAction extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public categoryAction() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String flag;
		flag=request.getParameter("flag");
		
		String msg;
		
		
		if(flag.equals("save"))
		{
		
		
		
		
		int catid;
		String catname,descr;
		
		catid=Integer.parseInt(  request.getParameter("catid"));
		catname=request.getParameter("catname");
		descr=request.getParameter("descr");
		
		
		
		categorymannager obj = new categorymannager();
		try {
			obj.getdata(catid, catname, descr);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
		
		else if(flag.equals("delete"))
		{
		
			int catid;
			
			catid=Integer.parseInt(  request.getParameter("catid"));
			
			
			
			categorymannager obj = new categorymannager();
			obj.deletedata(catid);
			
			
		}	
		
		
		else if(flag.equals("update"))
		{
			
			int catids;
			String catnames,descrs;
			
			catids=Integer.parseInt(  request.getParameter("catids"));
			catnames=request.getParameter("catnames");
			descrs=request.getParameter("descrs");
			
			categorymannager obj = new categorymannager();

			
			
			
			
			String msgs =obj.updatedata(catids, catnames, descrs);
			 
						
		}
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
