package xmlcalling;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import dbsaved.categorymannager;

public class categorycall {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Resource resource=new ClassPathResource("category.xml");  
		BeanFactory factory=new XmlBeanFactory(resource); 
		
		categorymannager category = (categorymannager)factory.getBean("catbean");
		System.out.println(category.searchdata());
		
		
		
	}

}
