

import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.eclipse.jdt.internal.compiler.ast.ReturnStatement;

import dbsaved.returnmannager;

/**
 * Servlet implementation class returnsAction
 */
@WebServlet("/returnsAction")
public class returnsAction extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public returnsAction() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String flag;
		flag=request.getParameter("flag");
		
		String msg;
		
		if(flag.equals("save"))
		{
		
		
		int rid,oid, pid,cusid;
		String comments,returndate;
		
		
		rid=Integer.parseInt(request.getParameter("rid"));
		oid=Integer.parseInt(request.getParameter("oid"));
		pid=Integer.parseInt(request.getParameter("pid"));
		cusid=Integer.parseInt(request.getParameter("cusid"));
		comments=request.getParameter("comments");
		returndate = request.getParameter("returndate");
		
		returnmannager obj = new returnmannager();
		try {
			obj.getdata(rid, oid, pid, cusid, comments, returndate);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
		else if(flag.equals("delete"))
		{
			
			int rid;
			
			rid=Integer.parseInt(request.getParameter("rid"));
			
			returnmannager obj=new returnmannager();
			obj.deletedata(rid);
			
			
			
		}
		
		else if(flag.equals("update"))
		{
			
			int rids,oids, pids,cusids;
			String commentss,returndates;
			
			
			rids=Integer.parseInt(request.getParameter("rids"));
			oids=Integer.parseInt(request.getParameter("oids"));
			pids=Integer.parseInt(request.getParameter("pids"));
			cusids=Integer.parseInt(request.getParameter("cusids"));
			commentss=request.getParameter("commentss");
			returndates = request.getParameter("returndates");

			returnmannager obj=new returnmannager();
			obj.updatedata(rids, oids, pids, cusids, commentss, returndates);
			
			
		}
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
