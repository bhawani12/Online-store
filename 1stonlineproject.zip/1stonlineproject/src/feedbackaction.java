

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dbsaved.feedbackmannager;

/**
 * Servlet implementation class feedbackaction
 */
@WebServlet("/feedbackaction")
public class feedbackaction extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public feedbackaction() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String flag;
		flag=request.getParameter("flag");
		String msg;
		
		if(flag.equals("save"))
		{
		
		
		
			int fid,cusid;
			String comments;
			
			fid=Integer.parseInt(request.getParameter("fid"));
			cusid=Integer.parseInt(request.getParameter("cusid"));
			comments=request.getParameter("comments");
			
			feedbackmannager obj= new feedbackmannager();
			try {
				obj.getdata(fid, cusid, comments);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		else if(flag.equals("delete"))
		{
			
			
			
			int fid;
			
			fid=Integer.parseInt(request.getParameter("fid"));
			
			feedbackmannager obj= new feedbackmannager();
			obj.deletedata(fid);
			
			//System.out.println(fid);
			
		}
		
		else if(flag.equals("update"))
		{
			
			int fids,cusids;
			String commentss;
			
			fids=Integer.parseInt(request.getParameter("fids"));
			cusids=Integer.parseInt(request.getParameter("cusids"));
			commentss=request.getParameter("commentss");
			
		feedbackmannager obj= new feedbackmannager();
		obj.updatedata(fids, cusids, commentss);
			
			
		}
			
			
			
			
			
			
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
