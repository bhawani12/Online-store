

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dbsaved.categorymannager;
import dbsaved.citymannager;

/**
 * Servlet implementation class cityAction
 */
@WebServlet("/cityAction")
public class cityAction extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public cityAction() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String flag;
		flag=request.getParameter("flag");
		
		String msg;
		
		
		if(flag.equals("save"))
		{
		
		
		
		int cid;
		String cityname ;
		
		cid=Integer.parseInt(request.getParameter("cid"));
		cityname=request.getParameter("cityname");
		
		citymannager obj= new citymannager();
		try {
			obj.getdata(cid, cityname);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
		
		
		else if(flag.equals("delete"))
		{
		
			int cid;
			
			cid=Integer.parseInt(  request.getParameter("cid"));
			
			
			
			citymannager obj = new citymannager();
			obj.deletedata(cid);
			
			
		}
		
		else if(flag.equals("update"))
		{
			int cids;
			String citynames ;
			
			cids=Integer.parseInt(request.getParameter("cids"));
			citynames=request.getParameter("citynames");
			
			citymannager obj= new citymannager();
			
			obj.updatedata(cids, citynames);
			
			
			
			
		}
			
			
			
			
			
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
