

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dbsaved.countrrymannager;
import dbsaved.subcategorymannager;

/**
 * Servlet implementation class subcategoryAction
 */
@WebServlet("/subcategoryAction")
public class subcategoryAction extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public subcategoryAction() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String flag;
		flag= request.getParameter("flag");
		
		String msg;
		
		
		
		
		
		if(flag.equals("save"))
		{
		
		
		
		
		int subcatid,catid;
		String subcatname;
		
		subcatid=Integer.parseInt(request.getParameter("subcatid"));
		catid=Integer.parseInt(request.getParameter("catid"));
		subcatname=request.getParameter("subcatname");
		
		subcategorymannager obj= new subcategorymannager();
		try {
			obj.getdata(subcatid, catid, subcatname);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
		
		else if(flag.equals("delete"))
		{
			int subcatid;
			
			subcatid=Integer.parseInt(  request.getParameter("subcatid"));
			
			
			
			subcategorymannager obj = new subcategorymannager();
			obj.deletedata(subcatid);
			
		}
		
		else if(flag.equals("update"))
		{

			int subcatids,catids;
			String subcatnames;
			
			subcatids=Integer.parseInt(request.getParameter("subcatids"));
			catids=Integer.parseInt(request.getParameter("catids"));
			subcatnames=request.getParameter("subcatnames");
			
			subcategorymannager obj = new subcategorymannager();
			obj.updatedata(subcatids, catids, subcatnames);
		
			
		}
		
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
