package main;

public class category {
	
	private int catid;
	private String catname;
	private String descr;
	
	
	public category(int catid) {
		super();
		this.catid = catid;
	}
	public String getDescr() {
		return descr;
	}
	public void setDescr(String descr) {
		this.descr = descr;
	}
	public int getCatid() {
		return catid;
	}
	public void setCatid(int catid) {
		this.catid = catid;
	}
	public String getCatname() {
		return catname;
	}
	public void setCatname(String catname) {
		this.catname = catname;
	}

	
	

}
