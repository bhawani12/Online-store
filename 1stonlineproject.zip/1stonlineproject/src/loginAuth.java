

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class loginAuth
 */
@WebServlet("/loginAuth")
public class loginAuth extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     * 
     */
    public loginAuth() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		session.setAttribute("uid", "na");
		
		
		
		String flag;
		flag = request.getParameter("flag");
		
		String msg="";
			
		if(flag.equals("reg"))
		{	
			
			String name,email,mob,pwd;
			name = request.getParameter("n");
			email= request.getParameter("e");
			mob = request.getParameter("m");
			pwd = request.getParameter("p");
			
			try
			{
				
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");
				
				PreparedStatement ps= con.prepareStatement("insert into login(name,email,password,mob) values(?,?,?,?)");
				
				ps.setString(1,name);
				ps.setString(2,email);
				ps.setString(3,pwd);
				ps.setString(4,mob);
				
				ps.executeUpdate();
				
				msg ="Account is created";
			}
			catch (Exception e) {
				// TODO: handle exception
				msg = e.toString();
			}
			
		}
		else if(flag.equals("signin"))
		{
			String email,pwd;
			email= request.getParameter("e");
			pwd = request.getParameter("p");
			
			
			
			
			
			try
			{

				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");
				
				String sql= "select * from login where email='"+email+"' and password='"+pwd+"'";
				Statement st = con.createStatement();
				ResultSet rs = st.executeQuery(sql);
				
				int counter=0;
				
				while(rs.next())
				{
					msg = rs.getString(1);
					counter++;
				}
				
				if(counter==0)
				{
					msg="fail";
				}
				else
				{
					session.setAttribute("uid", email);
						
				}
				
				msg ="Login Successfully";
			}
			catch (Exception e) {
				
				msg = e.toString();
			}
		}
		
		
		response.getWriter().append(msg);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
