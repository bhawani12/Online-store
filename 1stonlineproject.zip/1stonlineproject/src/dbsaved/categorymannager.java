package dbsaved;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class categorymannager {
	
	public String updatedata(int catids,String catnames,String descrs)
	{
		
		
		String msg="";
		
		
		String supdate="UPDATE category SET catname='"+catnames+"',descr='"+descrs+"' WHERE catid="+catids;
	
		
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");
			
			Statement st = con.createStatement();

			msg = supdate;
			
			st.executeUpdate(supdate);
			
		
				
	}
	catch (Exception e) {
		

		msg += e.toString();
		// TODO: handle exception
	}

	return msg;
}

		
		
		/*
		try(Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

				PreparedStatement ps= con.prepareStatement(supdate))
		{
			ps.setInt(1,catid);
			ps.setString(2, catname);
			ps.setString(3, descr);
			ps.executeUpdate();
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		return msg;

		
*/		
	
	
	public ArrayList<String> searchdata()
	{
		return null;
		/*try (Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

				PreparedStatement ps= con.prepareStatement("select * from category where catid=?;"))

		{
			int catid=i;
			ps.setInt(1, catid);
			ResultSet rs=ps.executeQuery();
			
			ArrayList<String> al =new ArrayList<String>();
			//String data="";
			while(rs.next())
			{
				System.out.println("hii");
				//data=rs.getInt(1)+rs.getString(2)+rs.getString(3);
				al.add(rs.getString("catname"));
				al.add(rs.getString("descr"));
			}
			
			return al;
		}
		catch (Exception e) {
			// TODO: handle exception
			return null;
		}
		*/
		
		
		
	}
	
	public void deletedata( int catid)
	{
		String sdel="DELETE from category WHERE catid=?";
		try(Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

				PreparedStatement ps= con.prepareStatement(sdel))
		{
			
			ps.setInt(1, catid);
			ps.executeUpdate();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.getMessage();
		}
		
	}

	
	public void getdata(int catid,String catname,String descr) throws ClassNotFoundException, SQLException
	{
	
	
	 
	
	
	catid=catid;
	catname=catname;
	descr=descr;
	
	Class.forName("com.mysql.jdbc.Driver");
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

	PreparedStatement ps= con.prepareStatement("insert into category(catid,catname,descr) values(?,?,?)");
	
	ps.setInt(1,catid);
	ps.setString(2,catname);
	ps.setString(3,descr);
	ps.executeUpdate();
	
	ps = con.prepareStatement("select * from category;");
	ResultSet rs=ps.executeQuery();
	
	while(rs.next())
	{
		System.out.println(rs.getInt(1)+rs.getString(2)+rs.getString(3));
		
		System.out.println("data saved..");
		con.close();

	}
	

	}
}
