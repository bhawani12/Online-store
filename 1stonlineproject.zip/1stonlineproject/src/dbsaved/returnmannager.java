package dbsaved;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;

public class returnmannager {
	public String updatedata(int rids,int oids,int pids,int cusids,String commentss,String returndates)
	{
		String supdate="UPDATE returns SET oid="+oids+" ,pid="+pids+" ,cusid="+cusids+" ,comments='"+commentss+"',returndate='"+returndates+"' WHERE rid="+rids;
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");
		
		Statement st = con.createStatement();

	
		
		st.executeUpdate(supdate);
		
	
			
}			catch (Exception e) {
			// TODO: handle exception
		}
		return supdate;

		
		
	}
	
	public ArrayList searchdata()
	{
		try (Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

				PreparedStatement ps= con.prepareStatement("select * from sales;"))

		{
			ResultSet rs=ps.executeQuery();
			
			ArrayList al =new ArrayList();
			String data="";
			while(rs.next())
			{
				data=rs.getInt(1)+rs.getInt(2)+rs.getInt(3)+rs.getInt(4)+rs.getInt(5)+rs.getString(6)+rs.getDate(7);
				al.add(data);
			}
			
			return al;
		}
		catch (Exception e) {
			// TODO: handle exception
			return null;
		}
		
		
		
		
	}
	
	public void deletedata( int rid)
	{
		String sdel="DELETE from returns WHERE rid=?";
		try(Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

				PreparedStatement ps= con.prepareStatement(sdel))
		{
			
			ps.setInt(1, rid);
			ps.executeUpdate();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.getMessage();
		}
		
	}


	
	public void getdata(int rid,int oid,int pid,int cusid,String comments,String returndate) throws ClassNotFoundException, SQLException
	{
	
	
	 
	
		 rid=rid;
		 oid=oid;
		 pid=pid;
		 cusid=cusid;
		 comments=comments;
		 returndate=returndate;
	
	
	Class.forName("com.mysql.jdbc.Driver");
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

	PreparedStatement ps= con.prepareStatement("insert into returns(rid,oid,pid,cusid,comments,returndate) values(?,?,?,?,?,?)");
	
	ps.setInt(1,rid);
	ps.setInt(2,oid);
	ps.setInt(3,pid);
	ps.setInt(4,cusid);
	ps.setString(5,comments);
	ps.setString(6, returndate);
	ps.executeUpdate();
	
	ps = con.prepareStatement("select * from returns;");
	ResultSet rs=ps.executeQuery();
	
	while(rs.next())
	{
		System.out.println(rs.getInt(1)+rs.getInt(2)+rs.getInt(3)+rs.getInt(4)+rs.getString(5)+rs.getString(6));
		
		System.out.println("data saved..");
		con.close();

	}
	

	}



}
