package dbsaved;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class subcategorymannager {
	
	public String updatedata(int subcatids,int catids,String subcatnames)
	{
		String supdate="UPDATE subcategory SET catid="+catids+" ,subcatname='"+subcatnames+"' WHERE subcatid="+subcatids;
try {
			
			Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");
		
		Statement st = con.createStatement();

		
		
		st.executeUpdate(supdate);
		}
		catch (Exception e) {
			// TODO: handle exception
		}
return supdate;

		
		
	}
	
	public ArrayList searchdata()
	{
		try (Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

				PreparedStatement ps= con.prepareStatement("select * from subcategory;"))

		{
			ResultSet rs=ps.executeQuery();
			
			ArrayList al =new ArrayList();
			String data="";
			while(rs.next())
			{
				data=rs.getInt(1)+rs.getInt(2)+rs.getString(3);
				al.add(data);
			}
			
			return al;
		}
		catch (Exception e) {
			// TODO: handle exception
			return null;
		}
		
		
		
		
	}
	
	public void deletedata( int subcatid)
	{
		String sdel="DELETE from subcategory WHERE subcatid=?";
		try(Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

				PreparedStatement ps= con.prepareStatement(sdel))
		{
			
			ps.setInt(1, subcatid);
			ps.executeUpdate();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.getMessage();
		}
		
	}
	
	public void getdata(int subcatid,int catid,String subcatname) throws ClassNotFoundException, SQLException
	{
	
	
	 
	
	
		subcatid=subcatid;
		catid=catid;
		subcatname=subcatname;
	
	
	Class.forName("com.mysql.jdbc.Driver");
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

	PreparedStatement ps= con.prepareStatement("insert into subcategory(subcatid,catid,subcatname) values(?,?,?)");
	
	ps.setInt(1,subcatid);
	ps.setInt(2,catid);
	ps.setString(3, subcatname);
	ps.executeUpdate();
	
	ps = con.prepareStatement("select * from subcategory;");
	ResultSet rs=ps.executeQuery();
	
	while(rs.next())
	{
		System.out.println(rs.getInt(1)+rs.getInt(2)+rs.getString(3));
		
		System.out.println("data saved..");
		con.close();

	}
	

	}


}
