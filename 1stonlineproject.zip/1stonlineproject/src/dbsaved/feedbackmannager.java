package dbsaved;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class feedbackmannager {
	
	public String updatedata(int fids,int cusids,String commentss)
	{
		String supdate="UPDATE feedback SET cusid='"+cusids+"',comments='"+commentss+"' WHERE fid="+fids;
		try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");
		
				Statement st = con.createStatement();
				
				
				st.executeUpdate(supdate);
			
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		return supdate;

		
		
	}
	
	public ArrayList searchdata()
	{
		try (Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

				PreparedStatement ps= con.prepareStatement("select * from feedback;"))

		{
			ResultSet rs=ps.executeQuery();
			
			ArrayList al =new ArrayList();
			String data="";
			while(rs.next())
			{
				data=rs.getInt(1)+rs.getInt(2)+rs.getString(3);
				al.add(data);
			}
			
			return al;
		}
		catch (Exception e) {
			// TODO: handle exception
			return null;
		}
		
		
		
		
	}
	
	public void deletedata( int fid)
	{
		
		String sdel="DELETE from feedback WHERE fid=?";
		try(Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

				PreparedStatement ps= con.prepareStatement(sdel))
		{
			
			ps.setInt(1, fid);
			ps.executeUpdate();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.getMessage();
		}
		
	}

	
	public void getdata(int fid,int cusid,String comments) throws ClassNotFoundException, SQLException
	{
	
	
	 
	
	fid=fid;
	cusid=cusid;
	comments=comments;
	
	
	Class.forName("com.mysql.jdbc.Driver");
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

	PreparedStatement ps= con.prepareStatement("insert into feedback(fid,cusid,comments) values(?,?,?)");
	
	ps.setInt(1,fid);
	ps.setInt(2,cusid);
	ps.setString(3,comments);
	ps.executeUpdate();
	
	ps = con.prepareStatement("select * from feedback;");
	ResultSet rs=ps.executeQuery();
	
	while(rs.next())
	{
		System.out.println(rs.getInt(1)+rs.getInt(2)+rs.getString(3));
		
		System.out.println("data saved..");
		con.close();

	}
	

	}


}
