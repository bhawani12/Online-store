package dbsaved;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;

public class salesmannager {
	
	public String updatedata(int oids,int cusids,int pids,int quantitys, int prices,String pnames,String orderdates)
	{
		String supdate="UPDATE sales SET cusid="+cusids+" ,pid="+pids+" ,quantity="+quantitys+" ,price="+prices+" ,pname='"+pnames+"' ,orderdate='"+orderdates+"' WHERE oid="+oids;
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");
		
		Statement st = con.createStatement();

		
		
		st.executeUpdate(supdate);
		
	
			
}		catch (Exception e) {
			// TODO: handle exception
		}
		return supdate;

		
		
	}
	
	public ArrayList searchdata()
	{
		try (Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

				PreparedStatement ps= con.prepareStatement("select * from sales;"))

		{
			ResultSet rs=ps.executeQuery();
			
			ArrayList al =new ArrayList();
			String data="";
			while(rs.next())
			{
				data=rs.getInt(1)+rs.getInt(2)+rs.getInt(3)+rs.getInt(4)+rs.getInt(5)+rs.getString(6)+rs.getDate(7);
				al.add(data);
			}
			
			return al;
		}
		catch (Exception e) {
			// TODO: handle exception
			return null;
		}
		
		
		
		
	}
	
	public void deletedata( int oid)
	{
		String sdel="DELETE from sales WHERE oid=?";
		try(Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

				PreparedStatement ps= con.prepareStatement(sdel))
		{
			
			ps.setInt(1, oid);
			ps.executeUpdate();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.getMessage();
		}
		
	}

	
	public void getdata(int oid,int cusid,int pid,int quantity,int price,String pname,String orderdate) throws ClassNotFoundException, SQLException
	{
	
	
	 
	
		oid=oid;
		cusid=cusid;
		pid=pid;
		quantity=quantity;
		price=price;
		pname=pname;
		orderdate=orderdate;
	
	
	
	Class.forName("com.mysql.jdbc.Driver");
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

	PreparedStatement ps= con.prepareStatement("insert into sales(oid,cusid,pid,quantity,price,pname,orderdate) values(?,?,?,?,?,?,?)");
	
	ps.setInt(1,oid);
	ps.setInt(2,cusid);
	ps.setInt(3,pid);
	ps.setInt(4,quantity);
	ps.setInt(5,price);
	ps.setString(6, pname);
	ps.setString(7,orderdate);
	ps.executeUpdate();
	
	ps = con.prepareStatement("select * from sales;");
	ResultSet rs=ps.executeQuery();
	
	while(rs.next())
	{
		System.out.println(rs.getInt(1)+rs.getInt(2)+rs.getInt(3)+rs.getInt(4)+rs.getInt(5)+rs.getString(6)+rs.getString(7));
		
		System.out.println("data saved..");
		con.close();

	}
	

	}


}
