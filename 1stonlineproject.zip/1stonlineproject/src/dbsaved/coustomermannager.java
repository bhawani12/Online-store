package dbsaved;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class coustomermannager {

	public String updatedata(int custids,String custnames,String genders,String mnos,String emailids,String addrs,int cids,int counids)
	{
		String supdate="UPDATE coustomer SET custname='"+custnames+"' ,gender='"+genders+"',mno='"+mnos+"',emailid='"+emailids+"',addr='"+addrs+"',cid="+cids+",counid='"+counids+"' WHERE custid="+custids;                   
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");
	
			Statement st = con.createStatement();
			
			
			st.executeUpdate(supdate);
	}		
	
	catch (Exception e) {
		// TODO: handle exception
	}
		return supdate;
	}
	
	public void searchdata()
	{
		
		
		
	}
	
	public void deletedata(int custid)
	{
		String sdel="DELETE from coustomer WHERE custid=?";
		try(Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

				PreparedStatement ps= con.prepareStatement(sdel))
		{
			
			ps.setInt(1, custid);
			ps.executeUpdate();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.getMessage();
		}

		
	}
	
	public void getdata(int custid,String custname,String gender,String mno,String emailid,String addr,int cid,int counid) throws ClassNotFoundException, SQLException
	{
	
	
	 
	
	custid=custid;
	custname=custname;
	gender=gender;
	mno=mno;
	emailid=emailid;
	addr=addr;
	cid=cid;
	counid=counid;
	
	
	
	Class.forName("com.mysql.jdbc.Driver");
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

	PreparedStatement ps= con.prepareStatement("insert into coustomer(custid,custname,gender,mno,emailid,addr,cid,counid) values(?,?,?,?,?,?,?,?)");
	
	ps.setInt(1,custid);
	ps.setString(2,custname);
	ps.setString(3,gender);
	ps.setString(4,mno);
	ps.setString(5,emailid);
	ps.setString(6,addr);
	ps.setInt(7,cid);
	ps.setInt(8,counid);
	ps.executeUpdate();
	
	ps = con.prepareStatement("select * from coustomer;");
	ResultSet rs=ps.executeQuery();
	
	while(rs.next())
	{
		System.out.println(rs.getInt(1)+rs.getString(2)+rs.getString(3)+rs.getString(4)+rs.getString(5)+rs.getString(6)+rs.getInt(7)+rs.getInt(8));
		
		System.out.println("data saved..");
		con.close();

	}
	

	}

}
