package dbsaved;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class countrrymannager {
	
	public String updatedata(int counids,String counnames)
	{
		String supdate="UPDATE countary SET counname='"+counnames+"' WHERE counid="+counids;
		try {
			
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");
		
				Statement st = con.createStatement();
				
				
				st.executeUpdate(supdate);
		}		
		
		catch (Exception e) {
			// TODO: handle exception
		}
		return supdate;

		
		
	}
	
	public ArrayList searchdata()
	{
		try (Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

				PreparedStatement ps= con.prepareStatement("select * from countary;"))

		{
			ResultSet rs=ps.executeQuery();
			
			ArrayList al =new ArrayList();
			String data="";
			while(rs.next())
			{
				data=rs.getInt(1)+rs.getString(2);
				al.add(data);
			}
			
			return al;
		}
		catch (Exception e) {
			// TODO: handle exception
			return null;
		}
		
		
		
		
	}
	
	public void deletedata( int counid)
	{
		String sdel="DELETE from countary WHERE counid=?";
		try(Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

				PreparedStatement ps= con.prepareStatement(sdel))
		{
			
			ps.setInt(1, counid);
			ps.executeUpdate();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.getMessage();
		}
		
	}

	
	public void getdata(int counid,String counname) throws ClassNotFoundException, SQLException
	{
	
	
	 
	
	
	counid=counid;
	counname=counname;
	
	
	Class.forName("com.mysql.jdbc.Driver");
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

	PreparedStatement ps= con.prepareStatement("insert into countary(counid,counname) values(?,?)");
	
	ps.setInt(1,counid);
	ps.setString(2,counname);
	ps.executeUpdate();
	
	ps = con.prepareStatement("select * from countary;");
	ResultSet rs=ps.executeQuery();
	
	while(rs.next())
	{
		System.out.println(rs.getInt(1)+rs.getString(2));
		
		System.out.println("data saved..");
		con.close();

	}
	

	}


}
