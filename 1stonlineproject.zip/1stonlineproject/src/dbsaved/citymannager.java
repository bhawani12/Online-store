package dbsaved;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class citymannager {

	public String updatedata(int cids,String citynames)
	{
		
		String msg="";
		
		
		String supdate="UPDATE city SET cityname='"+citynames+"' WHERE cid="+cids;
		
				try {
							
							Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");
						
						Statement st = con.createStatement();
				
						msg = supdate;
						
						st.executeUpdate(supdate);
						
					
							
				}
				catch (Exception e) {
					
				
					msg += e.toString();
					// TODO: handle exception
				}
				
					return msg;
				
					
					
	}
	
	public ArrayList searchdata()
	{
		try (Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

				PreparedStatement ps= con.prepareStatement("select * from city;"))

		{
			ResultSet rs=ps.executeQuery();
			
			ArrayList al =new ArrayList();
			String data="";
			while(rs.next())
			{
				data=rs.getInt(1)+rs.getString(2);
				al.add(data);
			}
			
			return al;
		}
		catch (Exception e) {
			// TODO: handle exception
			return null;
		}
		
		
		
		
	}
	
	public void deletedata( int cid)
	{
		String sdel="DELETE from city WHERE cid=?";
		try(Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

				PreparedStatement ps= con.prepareStatement(sdel))
		{
			
			ps.setInt(1, cid);
			ps.executeUpdate();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.getMessage();
		}
		
	}

	
	public void getdata(int cid,String cityname) throws ClassNotFoundException, SQLException
	{
	
	
	 
	
	
	cid=cid;
	cityname=cityname;
	
	
	Class.forName("com.mysql.jdbc.Driver");
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mannager", "root", "root");

	PreparedStatement ps= con.prepareStatement("insert into city(cid,cityname) values(?,?)");
	
	ps.setInt(1,cid);
	ps.setString(2,cityname);
	ps.executeUpdate();
	
	ps = con.prepareStatement("select * from city;");
	ResultSet rs=ps.executeQuery();
	
	while(rs.next())
	{
		System.out.println(rs.getInt(1)+rs.getString(2));
		
		System.out.println("data saved..");
		con.close();

	}
	

	}

}
