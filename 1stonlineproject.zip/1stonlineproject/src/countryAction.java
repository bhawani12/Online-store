

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dbsaved.countrrymannager;
import dbsaved.productmanager;

/**
 * Servlet implementation class countryAction
 */
@WebServlet("/countryAction")
public class countryAction extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public countryAction() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String flag;
		flag= request.getParameter("flag");
		
		String msg;
		
		
		
		
		
		if(flag.equals("save"))
		{
		int counid;
		String counname;
		
		counid=Integer.parseInt(request.getParameter("counid"));
		counname=request.getParameter("counname");
		
		countrrymannager obj = new countrrymannager();
		
		try {
			obj.getdata(counid, counname);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
		else if(flag.equals("delete"))
		{
			int counid;
			
			counid=Integer.parseInt(  request.getParameter("counid"));
			
			
			
			countrrymannager obj = new countrrymannager();
			obj.deletedata(counid);
			
		}
		
		else if(flag.equals("update"))
		{
			int counids;
			String counnames;
			
			counids=Integer.parseInt(request.getParameter("counids"));
			counnames=request.getParameter("counnames");
			
			countrrymannager obj= new countrrymannager();
			obj.updatedata(counids, counnames);
			
			
		}
		
		
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
