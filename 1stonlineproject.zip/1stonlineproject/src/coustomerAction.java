

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dbsaved.categorymannager;
import dbsaved.coustomermannager;

/**
 * Servlet implementation class coustomerAction
 */
@WebServlet("/coustomerAction")
public class coustomerAction extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public coustomerAction() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		String flag;
		flag=request.getParameter("flag");
		
		String msg;
		
		
		if(flag.equals("save"))
		{
	
		
		int custid,cid,counid;
		String custname,gender,mno,emailid,addr;
		
		custid=Integer.parseInt(request.getParameter("custid"));
		counid=Integer.parseInt(request.getParameter("counid"));
		cid=Integer.parseInt(request.getParameter("cid"));
		custname=request.getParameter("custname");
		gender=request.getParameter("gender");
		mno=request.getParameter("mno");
		emailid=request.getParameter("emailid");
		addr=request.getParameter("addr");
		
		coustomermannager obj= new coustomermannager();
		try {
			obj.getdata(custid, custname, gender, mno, emailid, addr, cid, counid);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
		
		else if(flag.equals("delete"))
		{
		
			int custid;
			
			custid=Integer.parseInt(  request.getParameter("custid"));
			
			
			
			coustomermannager obj = new coustomermannager();
			obj.deletedata(custid);
			
			
		}
		
		else if(flag.equals("update"))
		{
			
			int custids,cids,counids;
			String custnames,genders,mnos,emailids,addrs;
			
			custids=Integer.parseInt(request.getParameter("custids"));
			counids=Integer.parseInt(request.getParameter("counids"));
			cids=Integer.parseInt(request.getParameter("cids"));
			custnames=request.getParameter("custnames");
			genders=request.getParameter("genders");
			mnos=request.getParameter("mnos");
			emailids=request.getParameter("emailids");
			addrs=request.getParameter("addrs");
			
			coustomermannager obj = new coustomermannager();
			obj.updatedata(custids, custnames, genders, mnos, emailids, addrs, cids, counids);
			
			
		}
		
		
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
